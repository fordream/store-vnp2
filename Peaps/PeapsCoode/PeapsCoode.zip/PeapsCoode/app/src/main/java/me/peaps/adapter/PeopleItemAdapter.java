package me.peaps.adapter;

import android.content.Context;

import com.vnp.core.view.CustomLinearLayoutView;

import java.util.List;

import me.peaps.views.PeopleItemView;

public class PeopleItemAdapter extends BaseAdapter {
  public PeopleItemAdapter(Context context, List<Object> lData) {
    super(context, lData);
  }

  @Override
  public boolean isShowHeader(int i) {
    return false;
  }

  @Override
  public CustomLinearLayoutView getView(Context context, Object o) {
    return new PeopleItemView(context);
  }

  public void setData(List<Object> data) {
    this.clear();
    this.addAll(data);
    this.notifyDataSetChanged();
  }
}
