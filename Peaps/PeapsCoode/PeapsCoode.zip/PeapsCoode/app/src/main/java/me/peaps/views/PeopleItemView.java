package me.peaps.views;

import android.content.Context;

import com.vnp.core.view.CustomLinearLayoutView;

import me.peaps.R;
import me.peaps.models.PeopleChild;

public class PeopleItemView extends CustomLinearLayoutView {
  public PeopleItemView(Context context) {
    super(context);
    init(R.layout.peoplevitem);
    resize(findViewById(R.id.peoplevitem_main), 260, 130, 20);
    resize(findViewById(R.id.peoplevitem_main_img), 50, 50, 20);
    resize(findViewById(R.id.peoplevitem_main_text), 250,
            LayoutParams.WRAP_CONTENT, 35);
  }

  @Override
  public void setGender() {

    PeopleChild child = (PeopleChild) getData();
    child.render(this);
  }

  @Override
  public void showHeader(boolean arg0) {

  }
}