package me.peaps.models;

import me.peaps.views.PeopleItemView;

public abstract class PeopleChild extends BaseItem {

  public abstract void render(PeopleItemView peopleItemView);
}