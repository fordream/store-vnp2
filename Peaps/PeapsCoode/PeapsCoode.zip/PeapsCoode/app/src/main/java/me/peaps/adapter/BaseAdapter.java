/**
 * 
 */
package me.peaps.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.vnp.core.view.CustomLinearLayoutView;

import java.util.List;

public abstract class BaseAdapter extends ArrayAdapter<Object> {

	/**
	 * @param context
	 */
	public BaseAdapter(Context context, List<Object> lData) {
		super(context, 0, lData);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Object data = getItem(position);

		if (convertView == null) {
			convertView = getView(getContext(), data);
		}

		((CustomLinearLayoutView) convertView).setData(data);
		((CustomLinearLayoutView) convertView).setGender();
		((CustomLinearLayoutView) convertView).showHeader(isShowHeader(position));
		return convertView;
	}

	/**
	 * 
	 * @param position
	 * @return
	 */
	public abstract boolean isShowHeader(int position);

	public abstract CustomLinearLayoutView getView(Context context, Object data);
}