package me.peaps.models;

import android.widget.TextView;

import me.peaps.R;
import me.peaps.views.PeopleItemView;

public class PeopleChildText extends PeopleChild {

	private int resImg = R.drawable.email;
	private String str;

	public PeopleChildText(int resImg, String str) {
		this.resImg = resImg;
    this.str = str;
	}

  public void render(PeopleItemView peopleItemView) {
    ((TextView) peopleItemView.findViewById(R.id.peoplevitem_main_text)).setText(str);
    peopleItemView.findViewById(R.id.peoplevitem_main_img).setBackgroundResource(resImg);
  }
}