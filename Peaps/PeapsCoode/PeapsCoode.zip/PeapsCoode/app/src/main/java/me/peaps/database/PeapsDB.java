package me.peaps.database;

import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.vnp.core.datastore.DataStore;

import org.json.JSONObject;

import java.util.List;

import me.peaps.PeapsApplication;
import me.peaps.PeapsConfiguration;

public class PeapsDB {
  private static PeapsDB mInstance;

  /**
   * @return ApplicationController singleton instance
   */
  public static synchronized PeapsDB getInstance() {
    if(mInstance == null)
    {
      mInstance = new PeapsDB();
    }
    return mInstance;
  }

  private PeapsDB() {
    try{
      DataStore.getInstance().init(PeapsApplication.getInstance());
    }catch (Exception e){
      e.printStackTrace();
    }
  }

	public void saveEmail(String email) {
		DataStore.getInstance().save("myemail", email);
	}

	public String getEmail() {
		return DataStore.getInstance().get("myemail", "");
	}

//	public void saveMyInfor(String response) {
//		DataStore.getInstance().save("MyInfor", response);
//	}

//	public String getMyInfor() {
//		return DataStore.getInstance().get("MyInfor", "");
//	}

	public void saveScope(String scope) {
		DataStore.getInstance().save("scope", scope);
	}

	public String getScope() {
		return DataStore.getInstance().get("scope", "");
	}

	public void saveToken(String token) {
		DataStore.getInstance().save("token", token);
	}
	
	public String getToken() {
		return DataStore.getInstance().get("token", "");
	}

  public void getPeaps(final FindCallback<Peap> callback) {
    ParseQuery<Peap> query = ParseQuery.getQuery(Peap.class);
//    query.fromLocalDatastore();
    query.whereEqualTo("uemail", getEmail());
    query.orderByDescending("priorityScore");
    query.findInBackground(new FindCallback<Peap>() {
      @Override
      public void done(List<Peap> peaps, ParseException e) {
//        ParseObject.pinAllInBackground(peaps);
        if (e == null && peaps != null && peaps.size() > 0) {
          callback.done(peaps,e);
        }
      }
    });
  }

  public void getPeapsContact(final FindCallback<Peap> callback) {
    ParseQuery<Peap> query = ParseQuery.getQuery(Peap.class);
//    query.fromLocalDatastore();
    query.whereEqualTo("uemail", getEmail());
    query.orderByDescending("scopeScore");
    query.findInBackground(new FindCallback<Peap>() {
      @Override
      public void done(List<Peap> peaps, ParseException e) {
//        ParseObject.pinAllInBackground(peaps);
        if (e == null && peaps != null && peaps.size() > 0) {
          callback.done(peaps,e);
        }
      }
    });
  }

  public void kickOff(Response.Listener<JSONObject> success, Response.ErrorListener error) {
    final String URL = PeapsConfiguration.SERVER_KICKOFF_PATH +"?code="+getToken()+"&email="+getEmail();
    // pass second argument as "null" for GET requests
    JsonObjectRequest req = new JsonObjectRequest(URL, null, success, error);
    // add the request object to the queue to be executed
    PeapsApplication.getInstance().addToRequestQueue(req);
  }

  public void saveStatus(String email, final boolean status) {
    ParseQuery<Peap> query = ParseQuery.getQuery(Peap.class);

    query.whereEqualTo("uemail", getEmail());
    query.whereEqualTo("emails", email);

    query.findInBackground(new FindCallback<Peap>() {
      @Override
      public void done(List<Peap> peaps, ParseException e) {
        if (e == null && peaps != null && peaps.size() > 0) {
          Peap peap = peaps.get(0);
          peap.setScopeStatusManual(status ? 1 : 0);
          peap.saveEventually();
        }
      }
    });
  }
  public void logout(){

  }

  public void sendError(String s) {
    ParseObject error = new ParseObject("Error");
    error.put("log", s);
    try {
      error.save();
    } catch (ParseException e) {
      e.printStackTrace();
    }
  }
}