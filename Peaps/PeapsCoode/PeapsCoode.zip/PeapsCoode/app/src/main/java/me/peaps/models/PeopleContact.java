package me.peaps.models;

public class PeopleContact extends BaseItem {

	public PeopleContact() {
	}

	private int score;
  public String email;

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	private boolean isChecked;

	public boolean isChecked() {
		return isChecked;
	}

	public void setChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}

  public String getEmail() {
    return email;
  }
  public void setEmail(String _email) {
    email = _email;
  }

}