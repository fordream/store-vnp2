package me.peaps;

import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.Volley;
import com.parse.Parse;
import com.parse.ParseObject;
import com.vnp.core.activity.BaseApplication;

import java.io.PrintWriter;
import java.io.StringWriter;

import me.peaps.database.Peap;
import me.peaps.database.PeapsDB;

public class PeapsApplication extends BaseApplication {
  private static PeapsApplication sInstance;

  @Override
	public void onCreate() {
    sInstance = this;

		super.onCreate();

    // Setup handler for uncaught exceptions.
    final Thread.UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
    Thread.setDefaultUncaughtExceptionHandler (new Thread.UncaughtExceptionHandler()
    {
      @Override
      public void uncaughtException (Thread thread, Throwable e)
      {
        handleUncaughtException (thread, e);
        defaultUncaughtExceptionHandler.uncaughtException(thread, e);
      }
    });

    ParseObject.registerSubclass(Peap.class);
    Parse.enableLocalDatastore(this);
    Parse.initialize(this, PeapsConfiguration.PARSE_APP_ID, PeapsConfiguration.PARSE_CLIENT_KEY);

  }

  /**
   * @return ApplicationController singleton instance
   */
  public static synchronized PeapsApplication getInstance() {
    return sInstance;
  }

  /**
   * Log or request TAG
   */
  public static final String TAG = PeapsApplication.class.getName();

  private RequestQueue mRequestQueue;
  /**
   * @return The Volley Request queue, the queue will be created if it is null
   */
  public RequestQueue getRequestQueue() {
    // lazy initialize the request queue, the queue instance will be
    // created when it is accessed for the first time
    if (mRequestQueue == null) {
      mRequestQueue = Volley.newRequestQueue(getApplicationContext());
    }

    return mRequestQueue;
  }

  /**
   * Adds the specified request to the global queue, if tag is specified
   * then it is used else Default TAG is used.
   *
   * @param req
   * @param tag
   */
  public <T> void addToRequestQueue(Request<T> req, String tag) {
    // set the default tag if tag is empty
    req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);

    VolleyLog.d("Adding request to queue: %s", req.getUrl());

    getRequestQueue().add(req);
  }

  /**
   * Adds the specified request to the global queue using the Default TAG.
   *
   * @param req
   */
  public <T> void addToRequestQueue(Request<T> req) {
    // set the default tag if tag is empty
    req.setTag(TAG);

    getRequestQueue().add(req);
  }

  /**
   * Cancels all pending requests by the specified TAG, it is important
   * to specify a TAG so that the pending/ongoing requests can be cancelled.
   *
   * @param tag
   */
  public void cancelPendingRequests(Object tag) {
    if (mRequestQueue != null) {
      mRequestQueue.cancelAll(tag);
    }
  }

  public void handleUncaughtException (Thread thread, Throwable e)
  {
    e.printStackTrace(); // not all Android versions will print the stack trace automatically

    // Send to the DB
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    e.printStackTrace(pw);
    PeapsDB.getInstance().sendError(sw.toString());

//    Intent intent = new Intent ();
//    intent.setAction ("me.peaps.SEND_LOG"); // see step 5.
//    intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK); // required when starting from Application
//    startActivity (intent);

    System.exit(1); // kill off the crashed app
  }
}
