package me.peaps;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.google.android.gms.auth.GoogleAuthException;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.SignInButton;
import com.vnp.core.common.CommonAndroid;

import org.json.JSONObject;

import java.io.IOException;

import me.peaps.auth.google.GoogleApi;
import me.peaps.auth.google.IAbstractGetAuthCodeTaskCallBack;
import me.peaps.base.MBaseActivity;
import me.peaps.database.PeapsDB;

public class MainActivity extends MBaseActivity implements OnClickListener {
	private GoogleApi googleApi;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		googleApi = new GoogleApi(this, (TextView) findViewById(R.id.main_txt));

    SignInButton signInButton = (SignInButton) findViewById(R.id.sign_in_button);
    signInButton.setOnClickListener(this);
    setGooglePlusButtonText(signInButton, getString(R.string.sign_in));
		registerReceiver(broadcastReceiver, new IntentFilter(
				IAbstractGetAuthCodeTaskCallBack.ACTION_CALLBACK));
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		unregisterReceiver(broadcastReceiver);
	}

	private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			String str = intent
					.getStringExtra(IAbstractGetAuthCodeTaskCallBack.CALLBACK_VALUE);
			String email = intent
					.getStringExtra(IAbstractGetAuthCodeTaskCallBack.CALLBACK_EMAIL);
			int type = intent.getIntExtra(
					IAbstractGetAuthCodeTaskCallBack.CALLBACK_TYPE,
					IAbstractGetAuthCodeTaskCallBack.CALLBACK_TYPEEROR);

			if (type == IAbstractGetAuthCodeTaskCallBack.CALLBACK_TYPEEROR) {
				CommonAndroid.showDialog(MainActivity.this, str, null);
			} else {
        final PeapsDB db = PeapsDB.getInstance();
        db.saveEmail(email);

        //Kick off the server back end by sending the token
        PeapsDB.getInstance().kickOff(new Response.Listener<JSONObject>() {
          @Override
          public void onResponse(JSONObject response) {

            startActivity(new Intent(MainActivity.this,
                    PeopleScreenActivity.class));
            finish();

          }
        }, new Response.ErrorListener() {
          @Override
          public void onErrorResponse(VolleyError error) {
                new Thread(new Runnable() {
                  @Override
                  public void run() {
                    try {
                      GoogleAuthUtil.clearToken(MainActivity.this, db.getToken());
                    } catch (GoogleAuthException e) {
                      e.printStackTrace();
                    } catch (IOException e) {
                      e.printStackTrace();
                    }
                    googleApi.greetTheUser();
                  }
                }).start();
                VolleyLog.e("Error: ", error.getMessage());
          }
        });
			}
		}
	};

	@Override
	protected void onResume() {
		super.onResume();
		resize(findViewById(R.id.sign_in_button), 191, 36, 0);
		resize(findViewById(R.id.main_spacing), 191, 100, 0);
		resize(findViewById(R.id.imageView1), 166, 64, 0);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		googleApi.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.sign_in_button) {
       googleApi.greetTheUser();
		}
	}

  protected void setGooglePlusButtonText(SignInButton signInButton, String buttonText) {
    // Find the TextView that is inside of the SignInButton and set its text
    for (int i = 0; i < signInButton.getChildCount(); i++) {
      View v = signInButton.getChildAt(i);

      if (v instanceof TextView) {
        TextView tv = (TextView) v;
        tv.setText(buttonText);
        return;
      }
    }
  }
}
