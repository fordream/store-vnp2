package me.peaps.views;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;

import com.vnp.core.common.ImageLoaderUtils;
import com.vnp.core.view.CustomLinearLayoutView;

import java.util.ArrayList;
import java.util.List;

import me.peaps.R;
import me.peaps.adapter.PeopleItemAdapter;
import me.peaps.models.People;

public class PeopleView extends CustomLinearLayoutView implements
        AdapterView.OnItemClickListener, View.OnClickListener {

  private Gallery gallery;

  public PeopleView(Context context) {
    super(context);
    init(R.layout.peopleitem);
    gallery = (Gallery) findViewById(R.id.gallery1);
    gallery.setOnItemClickListener(this);
    adapter = new PeopleItemAdapter(context, new ArrayList<Object>());
    gallery.setAdapter(adapter);
  }

  @Override
  public void init(int res) {
    super.init(res);
    findViewById(R.id.peopleitem_content).setOnClickListener(this);
    resize(findViewById(R.id.peopleitem_content), 310,
            LayoutParams.WRAP_CONTENT, 0);
    resize(findViewById(R.id.peopleitem_name), 300,
            LayoutParams.WRAP_CONTENT, 25);
    resize(findViewById(R.id.peopleitem_time), 300,
            LayoutParams.WRAP_CONTENT, 22);
    resize(findViewById(R.id.peopleitem_img), 170, 170, 20);
    resize(findViewById(R.id.gallery1), 310, 130, 20);
  }

  private PeopleItemAdapter adapter;

  @Override
  public void setGender() {
    People people = (People) getData();
    setText(R.id.peopleitem_name, people.getName());
    setText(R.id.peopleitem_time,
            String.format(this.getContext().getString(R.string.its_been_x_months), people.getTime()));
    ImageLoaderUtils.getInstance(getContext()).DisplayImage(
            people.getImg(),
            (ImageView) findViewById(R.id.peopleitem_img));
    List<Object> list = people.getList();

    adapter.setData(list);
    gallery.setSelection(0);
  }

  private void setText(int peopleItemName, String name) {
    ((TextView) findViewById(peopleItemName)).setText(name);
  }

  @Override
  public void showHeader(boolean arg0) {

  }

  @Override
  public void onItemClick(AdapterView<?> arg0, View arg1, int position,
                          long arg3) {
    if (position == 0) {
      try {
        People people = (People) getData();
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL,
                new String[] { people.getEmail() });
        emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                this.getContext().getString(R.string.default_email_subject));
        emailIntent.putExtra(Intent.EXTRA_TEXT, this.getContext().getString(R.string.default_email_body));

        final PackageManager pm = this.getContext().getPackageManager();
        final List<ResolveInfo> matches = pm.queryIntentActivities(emailIntent, 0);
        ResolveInfo best = null;
        for (final ResolveInfo info : matches)
          if (info.activityInfo.packageName.endsWith(".gm") ||
                  info.activityInfo.name.toLowerCase().contains("gmail")) best = info;
        if (best != null)
          emailIntent.setClassName(best.activityInfo.packageName, best.activityInfo.name);

        this.getContext().startActivity(emailIntent);
      } catch (Exception exception) {

      }
    }
  }

  @Override
  public void onClick(View v) {
  }
}