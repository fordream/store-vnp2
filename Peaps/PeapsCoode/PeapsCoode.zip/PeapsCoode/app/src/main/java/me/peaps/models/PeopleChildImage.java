package me.peaps.models;

import me.peaps.R;
import me.peaps.views.PeopleItemView;

public class PeopleChildImage extends PeopleChild {

  private int resImg;

  public PeopleChildImage(int resImg) {
    this.resImg = resImg;
  }

  public void render(PeopleItemView peopleItemView) {
    peopleItemView.findViewById(R.id.peoplevitem_back_img).setBackgroundResource(resImg);
  }
}