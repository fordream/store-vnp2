package me.peaps.views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

import com.vnp.core.common.CommonAndroid;
//org.vnp.storeapp.views.MTetView
public class MTextView extends TextView {

	public MTextView(Context context) {
		super(context);
		CommonAndroid.FONT.setTypefaceFromAsset(this, "arial.ttf");
	}

	public MTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		CommonAndroid.FONT.setTypefaceFromAsset(this, "arial.ttf");
	}

	public MTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		CommonAndroid.FONT.setTypefaceFromAsset(this, "arial.ttf");
	}
}