package me.peaps.database;

import com.parse.ParseClassName;
import com.parse.ParseObject;

import org.json.JSONArray;

import java.util.concurrent.TimeUnit;

@ParseClassName("parsePeap")
public class Peap extends ParseObject{
  public Peap() {
    // A default constructor is required.
  }

  public String getImg() {
    return getString("img");
  }
  public String getID() {
    return getString("ID");
  }
  public Number getPriorityScore() {
    return getNumber("priorityScore");
  }
  public Number getScopeScore() {
    return getNumber("scopeScore");
  }
  public Number getScopeStatusManual() {
    return getNumber("scopeStatusManual");
  }
  public void setScopeStatusManual(Number scopeStatusManual) {
    put("scopeStatusManual", scopeStatusManual);
  }
  public String getName() {
    return getString("name");
  }
  public JSONArray getEmails() {
    return getJSONArray("emails");
  }
  public String getUemail() {
    return getString("uemail");
  }
  public String getLastContacted() {
//    return getString("lastContacted");
    Number time = getNumber("lastContacted2");
    long days = TimeUnit.DAYS.convert((long)time.doubleValue(), TimeUnit.SECONDS);
    long month = days/30;
    if(month > 0){
      return "["+month+"] months";
    }
    return "["+days+"] days";
  }
  public void setUemail(String uemail) {
    put("uemail", uemail);
  }

  public String getUname() {
    return getString("uname");
  }
  public void setUname(String uname) {
    put("uname", uname);
  }
}
