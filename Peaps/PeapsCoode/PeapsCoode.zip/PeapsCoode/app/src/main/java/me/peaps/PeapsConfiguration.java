package me.peaps;

public class PeapsConfiguration {
  public static final String PARSE_APP_ID = "z0tVwPXHKH0vpQ1elZuedq9yhEfdsuyZzB6gcVtV";
  public static final String PARSE_CLIENT_KEY = "dzQZBgiSRokAzPe5cgt36Kanuc1gecvHkRyLh21M";
  public static final String SERVER_KICKOFF_PATH = "http://peaps.me/kickoff";
  public static final String GOOGLE_CLIENT_ID = "223831830375-9v1i6j0vtmtf4kgtvmq9i98hpsh3and4.apps.googleusercontent.com";
  public static final String GOOGLE_SCOPE = "https://www.googleapis.com/auth/gmail.readonly profile email";
}
