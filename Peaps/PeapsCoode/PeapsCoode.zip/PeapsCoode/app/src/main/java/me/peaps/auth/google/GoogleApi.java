package me.peaps.auth.google;

import android.accounts.AccountManager;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.AccountPicker;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.vnp.core.datastore.DataStore;

import me.peaps.PeapsConfiguration;
import me.peaps.PeapsUtils;
import me.peaps.R;
import me.peaps.database.PeapsDB;

public class GoogleApi {
  public static final String SCOPE = "oauth2:server:client_id:"+PeapsConfiguration.GOOGLE_CLIENT_ID +":api_scope:"+PeapsConfiguration.GOOGLE_SCOPE;

  public static final int REQUEST_CODE_PICK_ACCOUNT = 1000;
	public static final int REQUEST_CODE_RECOVER_FROM_AUTH_ERROR = 1001;
	public static final int REQUEST_CODE_RECOVER_FROM_PLAY_SERVICES_ERROR = 1002;
	private IAbstractGetAuthCodeTaskCallBack abstractGetAuthCodeTaskCallBack;
	private Activity mContext;
	private String mEmail;

	public GoogleApi(Activity mContext, TextView mOut) {
		this.mContext = mContext;
		DataStore.getInstance().init(mContext);
		abstractGetAuthCodeTaskCallBack = new IAbstractGetAuthCodeTaskCallBack(
				mContext, mOut);
	}

	public AbstractGetAuthCodeTask getTask(Activity activity, String email,
			String scope,
			IAbstractGetAuthCodeTaskCallBack iAbstractGetAuthCodeTaskCallBack) {
		PeapsDB peapsDB = PeapsDB.getInstance();
		peapsDB.saveEmail(email);
		peapsDB.saveScope(scope);
		return new AbstractGetAuthCodeTask(activity, email, scope,
            iAbstractGetAuthCodeTaskCallBack);
	}

	public void pickUserAccount() {
		String[] accountTypes = new String[] { "com.google" };
		Intent intent = AccountPicker.newChooseAccountIntent(null, null,
				accountTypes, false, null, null, null, null);
		mContext.startActivityForResult(intent,
				GoogleApi.REQUEST_CODE_PICK_ACCOUNT);
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == GoogleApi.REQUEST_CODE_PICK_ACCOUNT) {
			if (resultCode == Activity.RESULT_OK) {
				mEmail = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
				getAuthCode();
			} else if (resultCode == Activity.RESULT_CANCELED) {
				Toast.makeText(mContext, "You must pick an account",
						Toast.LENGTH_SHORT).show();
			}
		} else if ((requestCode == GoogleApi.REQUEST_CODE_RECOVER_FROM_AUTH_ERROR || requestCode == GoogleApi.REQUEST_CODE_RECOVER_FROM_PLAY_SERVICES_ERROR)
				&& resultCode == Activity.RESULT_OK) {
			if (data == null) {
				abstractGetAuthCodeTaskCallBack
						.showErrorMessage("Unknown error, click the button again");
				return;
			}
			if (resultCode == Activity.RESULT_OK) {
				getTask(mContext, mEmail, GoogleApi.SCOPE,
                abstractGetAuthCodeTaskCallBack).execute();
				return;
			}
			if (resultCode == Activity.RESULT_CANCELED) {
				abstractGetAuthCodeTaskCallBack
						.showErrorMessage("User rejected authorization.");
				return;
			}
			abstractGetAuthCodeTaskCallBack
					.showErrorMessage("Unknown error, click the button again");
			return;
		}
	}

	public void getAuthCode() {
		if (mEmail == null) {
			pickUserAccount();
		} else {
			if (PeapsUtils.isDeviceOnline(mContext)) {
				getTask(mContext, mEmail, GoogleApi.SCOPE,
                abstractGetAuthCodeTaskCallBack).execute();
			} else {
				Toast.makeText(mContext, "No network connection available",
						Toast.LENGTH_SHORT).show();
			}
		}
	}

	public void greetTheUser() {
    int statusCode = GooglePlayServicesUtil
				.isGooglePlayServicesAvailable(mContext);
		if (statusCode == ConnectionResult.SUCCESS) {
			getAuthCode();
		} else if (GooglePlayServicesUtil.isUserRecoverableError(statusCode)) {
			Dialog dialog = GooglePlayServicesUtil.getErrorDialog(statusCode,
					mContext, 0 /* request code not used */);
			dialog.show();
		} else {
			Toast.makeText(mContext, R.string.unrecoverable_error,
					Toast.LENGTH_SHORT).show();
		}
	}

}