package me.peaps.views;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;

import com.vnp.core.view.CustomLinearLayoutView;

import me.peaps.ContactScreenActivity;
import me.peaps.MainActivity;
import me.peaps.R;
import me.peaps.database.PeapsDB;

public class HeaderView extends CustomLinearLayoutView implements
		OnClickListener {

	public HeaderView(Context context) {
		super(context);
    init(R.layout.headerview);
	}

	public HeaderView(Context context, AttributeSet attrs) {
		super(context, attrs);
    init(R.layout.headerview);
	}

	@Override
	public void init(int res) {
    try {
      super.init(res);
    }catch(Exception e){
      e.printStackTrace();
    }
		resize(findViewById(R.id.header_mmm), LayoutParams.FILL_PARENT, 50, 0);
		resize(findViewById(R.id.headerview_back), 46, 50, 0);
		resize(findViewById(R.id.headerview_logo), 83, 32, 0);
		resize(findViewById(R.id.headerview_back_1), 10, 50, 0);
//		resize(findViewById(R.id.headerview_contact_1), 10, 50, 0);

    resize(findViewById(R.id.headerview_logout), 32, 32, 0);
		resize(findViewById(R.id.headerview_contact), 32, 32, 0);

		findViewById(R.id.headerview_back).setOnClickListener(this);
		findViewById(R.id.headerview_contact).setOnClickListener(this);
    findViewById(R.id.headerview_logout).setOnClickListener(this);

		if(getContext() instanceof ContactScreenActivity){
			findViewById(R.id.headerview_contact).setVisibility(GONE);
		}
	}

	@Override
	public void setGender() {

	}

	@Override
	public void showHeader(boolean arg0) {

	}

	public void setShowBack(boolean showBack) {
		findViewById(R.id.headerview_back).setVisibility(
				showBack ? View.VISIBLE : View.GONE);
		findViewById(R.id.headerview_back_1).setVisibility(
				showBack ? View.GONE : View.VISIBLE);
	}

	@Override
	public void onClick(View arg0) {
    if (R.id.headerview_logout == arg0.getId()){
      new AlertDialog.Builder(getContext())
              .setIcon(android.R.drawable.ic_dialog_alert)
              .setTitle(R.string.logout)
              .setMessage(R.string.continue_log_lout)
              .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                  PeapsDB.getInstance().logout();
                  ((Activity) getContext()).finish();
                  Intent intent = new Intent(getContext(),
                          MainActivity.class);
                  // intent.putExtra("id", people.getId());
                  getContext().startActivity(intent);
                }

              })
              .setNegativeButton(R.string.cancel, null)
              .show();
    }
    else if (R.id.headerview_back == arg0.getId())
			((Activity) getContext()).finish();
		else {
//			People people = (People) getData();
			Intent intent = new Intent(getContext(),
					ContactScreenActivity.class);
			// intent.putExtra("id", people.getId());
			getContext().startActivity(intent);
		}
	}
}