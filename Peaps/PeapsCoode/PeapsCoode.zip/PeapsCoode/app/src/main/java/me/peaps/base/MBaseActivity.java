package me.peaps.base;

import android.os.Bundle;

import com.vnp.core.activity.BaseActivity;

public class MBaseActivity extends BaseActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

}