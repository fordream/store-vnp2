package me.peaps;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.vnp.core.v2.BaseAdapter;
import com.vnp.core.view.CustomLinearLayoutView;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import me.peaps.base.MHeaderBaseActivity;
import me.peaps.database.Peap;
import me.peaps.database.PeapsDB;
import me.peaps.models.People;
import me.peaps.models.PeopleChildImage;
import me.peaps.models.PeopleChildText;
import me.peaps.views.PeopleView;

public class PeopleScreenActivity extends MHeaderBaseActivity {

//  private GoogleApi googleApi;

  public boolean isShowBack() {
    return false;
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
//    registerReceiver(broadcastReceiver, new IntentFilter(
//            IAbstractGetAuthCodeTaskCallBack.ACTION_CALLBACK));
//    googleApi = new GoogleApi(this, null);
  }

//  private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
//
//    @Override
//    public void onReceive(Context context, Intent intent) {
//      String str = intent
//              .getStringExtra(IAbstractGetAuthCodeTaskCallBack.CALLBACK_VALUE);
//      String email = intent
//              .getStringExtra(IAbstractGetAuthCodeTaskCallBack.CALLBACK_EMAIL);
//      int type = intent.getIntExtra(
//              IAbstractGetAuthCodeTaskCallBack.CALLBACK_TYPE,
//              IAbstractGetAuthCodeTaskCallBack.CALLBACK_TYPEEROR);
//
//      if (type == IAbstractGetAuthCodeTaskCallBack.CALLBACK_TYPEEROR) {
//        CommonAndroid.showDialog(PeopleScreenActivity.this, str, null);
//      } else {
//        PeapsDB db = PeapsDB.getInstance();
//        db.saveEmail(email);
//
//        //Kick off the server back end by sending the token
//        PeapsDB.getInstance().kickOff();
//      }
//    }
//  };


  @Override
  public CustomLinearLayoutView getViewItem(Context arg0, Object arg1) {
    return new PeopleView(arg0);
  }

  @Override
  protected void onResume() {
    super.onResume();
//    PeapsDB.getInstance().kickOff();
//    googleApi.greetTheUser();
  }
  @Override
  protected void onDestroy() {
    super.onDestroy();
//    unregisterReceiver(broadcastReceiver);
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
//    googleApi.onActivityResult(requestCode, resultCode, data);
  }

  @Override
  public void loadData(final BaseAdapter adapter) {
    PeapsDB.getInstance().getPeaps(new FindCallback<Peap>() {
      @Override
      public void done(List<Peap> peaps, ParseException e) {
        if(peaps==null){
          return;
        }
        List<People> list = new ArrayList<People>();
        for (Peap peap : peaps) {
          String name = peap.getName();

          People people = new People();
          people.setImg(peap.getImg());
          people.setName(name);
          people.setTime(peap.getLastContacted());

          if(peap.getEmails()!=null && peap.getEmails().length()>0){
            try {
              people.setEmail(peap.getEmails().getString(0));
            } catch (JSONException e1) {
              e1.printStackTrace();
            }
            people.addChild(new PeopleChildText(R.drawable.email,
                    "Share what you've been up to"));
          }

          people.addChild(new PeopleChildImage(R.drawable.cardbday));
          people.addChild(new PeopleChildImage(R.drawable.cardfb));
          people.addChild(new PeopleChildImage(R.drawable.cardnews));

          people.addChild(new PeopleChildText(R.drawable.remind,
                  String.format("Remind me to reach out to %s later", name)));

          list.add(people);
        }
        adapter.addAll(list);
        adapter.notifyDataSetChanged();
      }
    });
//		for (int i = 0; i < 10; i++) {
//			People people = new People();
//			people.setId("000" + i);
//			people.setImg("http://files.jimeh.me/.blog/jimeh_2.0_large-20100205-042205.jpg");
//			people.setName("Chris Sculin");
//			people.setTime("3");
//			people.setEmail("exam" + i + "@gmail.com");
//			people.addChild(new PeopleChild(R.drawable.email,
//					R.string.people_child1));
//			people.addChild(new PeopleChild(R.drawable.like,
//					R.string.people_child2));
//			people.addChild(new PeopleChild(R.drawable.birthday,
//					R.string.people_child3));
//			people.addChild(new PeopleChild(R.drawable.chris,
//					R.string.people_child4));
//			people.addChild(new PeopleChild(R.drawable.remind,
//					R.string.people_child5));
//
//			list.add(people);
//		}
  }
}