package me.peaps;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.vnp.core.common.VNPResize.ICompleteInit;

import me.peaps.database.PeapsDB;
import me.peaps.base.MBaseActivity;

public class SplashActivity extends MBaseActivity implements ICompleteInit {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.splash);
    initVNPResize(this, 320, 0, this,
            (TextView) findViewById(R.id.splash_txt));
  }

  @Override
  public void complete() {
    if (!isFinishing()) {
      PeapsDB peapsDB = PeapsDB.getInstance();
      String email = peapsDB.getEmail();
      Intent intent;
      if(!email.isEmpty()){
        intent = new Intent(this, PeopleScreenActivity.class);
      }else{
        intent = new Intent(this, MainActivity.class);
      }
      startActivity(intent);
      finish();
    }
  }

  @Override
  protected void onPause() {
    super.onPause();
    finish();
  }
}
