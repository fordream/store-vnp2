package me.peaps;

import android.content.Context;
import android.os.Bundle;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.vnp.core.v2.BaseAdapter;
import com.vnp.core.view.CustomLinearLayoutView;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import me.peaps.base.MHeaderBaseActivity;
import me.peaps.database.Peap;
import me.peaps.database.PeapsDB;
import me.peaps.models.PeopleContact;
import me.peaps.views.ContactView;

public class ContactScreenActivity extends MHeaderBaseActivity {
  public boolean isShowBack() {
    return true;
  }

  private String id;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    id = getIntent().getStringExtra("id");
  }

  @Override
  public CustomLinearLayoutView getViewItem(Context arg0, Object arg1) {
    return new ContactView(arg0);
  }

  public void loadData(final BaseAdapter adapter) {
    PeapsDB.getInstance().getPeapsContact(new FindCallback<Peap>() {
      @Override
      public void done(List<Peap> peaps, ParseException e) {
        if(peaps==null){
          return;
        }
        List<PeopleContact> list = new ArrayList<PeopleContact>();
        for (Peap peap : peaps) {
          if(peap.getEmails()!=null && peap.getEmails().length()>0){
            PeopleContact peopleContact = new PeopleContact();
            try {
              peopleContact.setEmail(peap.getEmails().getString(0));
            } catch (JSONException e1) {
              e1.printStackTrace();
            }

            peopleContact.setImg(peap.getImg());
            peopleContact.setName(peap.getName());
            peopleContact.setScore(peap.getScopeScore().intValue());
            peopleContact.setChecked(peap.getScopeStatusManual().intValue() == 1 ? true : false);
            list.add(peopleContact);
          }
        }
        adapter.addAll(list);
        adapter.notifyDataSetChanged();
      }
    });
//		List<Object> list = new ArrayList<Object>();
//		for (int i = 0; i < 100; i++) {
//			PeopleContact peopleContact = new PeopleContact();
//			peopleContact.setId("000" + i);
//			peopleContact.setImg("http://files.jimeh.me/.blog/jimeh_2.0_large-20100205-042205.jpg");
//			peopleContact.setName("Chris Sculin");
//			peopleContact.setScore(new Random().nextInt(100) + 1);
//			peopleContact.setChecked(new Random().nextBoolean());
//			list.add(peopleContact);
//		}
//
//		Comparator<Object> comparator = new Comparator<Object>() {
//
//			@Override
//			public int compare(Object lhs, Object rhs) {
//				return ((PeopleContact) lhs).getScore() > ((PeopleContact) rhs)
//						.getScore() ? -1 : 1;
//			}
//		};
//		Collections.sort(list, comparator);
//		return list;
  }

}
