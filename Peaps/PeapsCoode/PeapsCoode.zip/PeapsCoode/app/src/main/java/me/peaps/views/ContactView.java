package me.peaps.views;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.vnp.core.common.ImageLoaderUtils;
import com.vnp.core.view.CustomLinearLayoutView;

import me.peaps.R;
import me.peaps.database.PeapsDB;
import me.peaps.models.PeopleContact;

public class ContactView extends CustomLinearLayoutView implements
        View.OnClickListener {

  public ContactView(Context context) {
    super(context);
    init(R.layout.contactitem);
  }

  @Override
  public void init(int res) {
    super.init(res);

    findViewById(R.id.contactitem_check).setOnClickListener(this);

    resize(findViewById(R.id.contactitem_main), 300, 60, 0);
    resize(findViewById(R.id.contactitem_avatar), 40, 40, 0);
    resize(findViewById(R.id.contactitem_check), 30, 30, 0);
    resize(findViewById(R.id.contactitem_text),
            LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, 20);
    resize(findViewById(R.id.contactitem_text_per),
            LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, 20);

  }

  @Override
  public void setGender() {
    PeopleContact contact = (PeopleContact) getData();
    setText(R.id.contactitem_text, contact.getName());
    setText(R.id.contactitem_text_per, contact.getScore() + "%");
    ImageLoaderUtils.getInstance(getContext()).DisplayImage(
            contact.getImg(),
            (ImageView) findViewById(R.id.contactitem_avatar));
    updateChecked(contact);
  }

  private void updateChecked(PeopleContact contact) {
    findViewById(R.id.contactitem_check).setBackgroundResource(
            contact.isChecked() ? R.drawable.peaps_check : R.drawable.peaps_plus);
  }

  private void setText(int peopleItemName, String name) {
    ((TextView) findViewById(peopleItemName)).setText(name);
  }

  @Override
  public void showHeader(boolean arg0) {

  }

  @Override
  public void onClick(View v) {
    PeapsDB peapsDB = PeapsDB.getInstance();
    PeopleContact contact = (PeopleContact) getData();
    boolean status = !contact.isChecked();
    contact.setChecked(status);
    updateChecked(contact);
    peapsDB.saveStatus(contact.getEmail(),status);
  }
}
