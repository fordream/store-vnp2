package com.vnp.core.base;

import com.vnp.core.common.VNPResize;
import com.vnp.core.common.VNPResize.ICompleteInit;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

public class ViewPagerNoneScroll extends ViewPager {
	private VNPResize vnpResize = VNPResize.getInstance();

	/**
	 * 
	 * @param context
	 * @param baseWidth
	 * @param baseHeight
	 * @param completeInit
	 * @param textView
	 */
	public void initVNPResize(Context context, int baseWidth, int baseHeight,
			ICompleteInit completeInit, TextView textView) {
		vnpResize.init(getContext(), baseWidth, baseHeight, completeInit, textView);
	}

	/**
	 * 
	 * @param v
	 * @param width
	 * @param height
	 * @param textSize
	 */
	public void resize(View v, int width, int height, int textSize) {
		vnpResize.resizeSacle(v, width, height);
		vnpResize.setTextsize(v, textSize);
	}
	public ViewPagerNoneScroll(Context context) {
		super(context);
	}

	public ViewPagerNoneScroll(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	private boolean isPagingEnabled;

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (this.isPagingEnabled) {
			return super.onTouchEvent(event);
		}

		return false;
	}

	@Override
	public boolean onInterceptTouchEvent(MotionEvent event) {
		if (this.isPagingEnabled) {
			return super.onInterceptTouchEvent(event);
		}

		return false;
	}

	public void setPagingEnabled(boolean b) {
		this.isPagingEnabled = b;
	}
}
