package com.vnp.core.activity;

import java.util.ArrayList;
import java.util.List;

import com.vnp.core.common.VNPResize;
import com.vnp.core.common.VNPResize.ICompleteInit;

import android.app.Activity;
import android.app.ActivityGroup;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class BaseGroupActivity extends ActivityGroup {
	private boolean canFinish = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	private VNPResize vnpResize = VNPResize.getInstance();

	/**
	 * 
	 * @param context
	 * @param baseWidth
	 * @param baseHeight
	 * @param completeInit
	 * @param textView
	 */
	public void initVNPResize(Context context, int baseWidth, int baseHeight,
			ICompleteInit completeInit, TextView textView) {
		vnpResize.init(this, baseWidth, baseHeight, completeInit, textView);
	}

	/**
	 * 
	 * @param v
	 * @param width
	 * @param height
	 * @param textSize
	 */
	public void resize(View v, int width, int height, int textSize) {
		vnpResize.resizeSacle(v, width, height);
		vnpResize.setTextsize(v, textSize);
	}

	@Override
	protected void onResume() {
		super.onResume();

	}

	// Keep this in a static variable to make it accessible for all the nested
	// activities, lets them manipulate the view
	// public static FirstGroup group;

	public boolean isCanFinish() {
		return canFinish;
	}

	public void setCanFinish(boolean canFinish) {
		this.canFinish = canFinish;
	}

	// Need to keep track of the history if you want the back-button to work
	// properly, don't use this if your activities requires a lot of memory.
	private List<View> history = new ArrayList<View>();

	public void addView(String name, Class<?> activity, Bundle extras) {
		replaceView(createView(name, activity, extras));
	}

	private View createView(String name, Class<?> activity, Bundle extras) {
		Intent intent = new Intent(this, activity);
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

		if (extras != null) {
			intent.putExtras(extras);
		}

		View view = getLocalActivityManager().startActivity(name, intent)
				.getDecorView();
		return view;
	}

	private void replaceView(View v) {
		// Adds the old one to history
		history.add(v);
		// Changes this Groups View to the new View.
		setContentView(v);
	}

	public void onBackPressed() {
		if (history.size() > 1) {
			history.remove(history.size() - 1);
			View view = history.get(history.size() - 1);
			setContentView(view);
		} else {
			if (canFinish) {
				// finish();
			} else {
				Activity activity = getParent();
				if (activity != null) {
					activity.onBackPressed();
				}
			}
		}
	}

	public void onBackPressed(Bundle extras, String actionForSendBoardCast) {
		onBackPressed();
		if (actionForSendBoardCast != null) {
			Intent intent = new Intent(actionForSendBoardCast);
			if (extras != null) {
				intent.putExtras(extras);
			}

			sendBroadcast(intent);
		}

	}

	protected Context getContext() {
		return this;
	}

	protected Activity getActivity() {
		return this;
	}
}