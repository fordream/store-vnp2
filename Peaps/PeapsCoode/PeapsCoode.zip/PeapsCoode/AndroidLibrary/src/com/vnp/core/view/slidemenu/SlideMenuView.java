package com.vnp.core.view.slidemenu;

import com.vnp.core.view.CustomLinearLayoutView;

import android.content.Context;
import android.util.AttributeSet;

public class SlideMenuView extends CustomLinearLayoutView {

	public SlideMenuView(Context context) {
		super(context);
	}

	public SlideMenuView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	@Override
	public void showHeader(boolean isShowHeader) {

	}

	@Override
	public void setGender() {

	}
}
