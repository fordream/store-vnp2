/**
 * 
 */
package com.vnp.core.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.vnp.core.common.VNPResize;
import com.vnp.core.common.CommonAndroid.RESIZE;
import com.vnp.core.common.VNPResize.ICompleteInit;

/**
 * @author tvuong1pc
 * 
 */
public abstract class CustomLinearLayoutView extends LinearLayout {
	private Object data;

	/**
	 * 
	 * @param isShowHeader
	 */
	public abstract void showHeader(boolean isShowHeader);

	/**
	 * @param context
	 */
	public CustomLinearLayoutView(Context context) {
		super(context);
		// baseResizeConfige = new BaseResizeConfige(getContext());
	}

	/**
	 * @param context
	 * @param attrs
	 */
	public CustomLinearLayoutView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// baseResizeConfige = new BaseResizeConfige(getContext());
	}

	public void init(int res) {
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(
				Context.LAYOUT_INFLATER_SERVICE);
		li.inflate(res, this);

	}

	/**
	 * convert view from resource
	 * 
	 * @param res
	 * @return
	 */
	public <T extends View> T getView(int res) {
		@SuppressWarnings("unchecked")
		T view = (T) findViewById(res);
		return view;
	}

	public void setData(Object data) {
		// todo
		this.data = data;
	}

	public Object getData() {
		return data;
	}

	private VNPResize vnpResize = VNPResize.getInstance();

	/**
	 * 
	 * @param context
	 * @param baseWidth
	 * @param baseHeight
	 * @param completeInit
	 * @param textView
	 */
	public void initVNPResize(Context context, int baseWidth, int baseHeight,
			ICompleteInit completeInit, TextView textView) {
		vnpResize.init(getContext(), baseWidth, baseHeight, completeInit, textView);
	}

	/**
	 * 
	 * @param v
	 * @param width
	 * @param height
	 * @param textSize
	 */
	public void resize(View v, int width, int height, int textSize) {
		vnpResize.resizeSacle(v, width, height);
		vnpResize.setTextsize(v, textSize);
	}

	public abstract void setGender();

}