package com.vnp.core.base;

import java.util.List;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

public abstract class MBaseAdapter extends BaseAdapter {
	public interface ViewHolder {
		public void init(View v);

		public void updateView(Object data);
	}

	public abstract int resLayout();

	public abstract ViewHolder getViewHolder();

	private List<Object> list;

	public MBaseAdapter(List<Object> list) {
		this.list = list;
	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder viewHolder;
		if (convertView == null) {
			convertView = ((Activity) parent.getContext()).getLayoutInflater().inflate(resLayout(), parent, false);
			viewHolder = getViewHolder();
			viewHolder.init(convertView);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}

		viewHolder.updateView(getItem(position));

		return convertView;
	}
}