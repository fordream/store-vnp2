/**
 * 
 */
package com.vnp.core.activity;

import android.R;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;

import com.vnp.core.common.VNPResize;
import com.vnp.core.common.VNPResize.ICompleteInit;

/**
 * class base for all activity
 * 
 * @author tvuong1pc
 * 
 */
public abstract class BaseTabActivity extends TabActivity implements
		OnTabChangeListener {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (getLayout() != 0)
			setContentView(getLayout());
	}

	public abstract int getLayout();

	private VNPResize vnpResize = VNPResize.getInstance();

	/**
	 * 
	 * @param context
	 * @param baseWidth
	 * @param baseHeight
	 * @param completeInit
	 * @param textView
	 */
	public void initVNPResize(Context context, int baseWidth, int baseHeight,
			ICompleteInit completeInit, TextView textView) {
		vnpResize.init(this, baseWidth, baseHeight, completeInit, textView);
	}

	/**
	 * 
	 * @param v
	 * @param width
	 * @param height
	 * @param textSize
	 */
	public void resize(View v, int width, int height, int textSize) {
		vnpResize.resizeSacle(v, width, height);
		vnpResize.setTextsize(v, textSize);
	}

	@Override
	protected void onResume() {
		super.onResume();

	}

	/**
	 * convert view from resource
	 * 
	 * @param res
	 * @return
	 */
	public <T extends View> T getView(int res) {
		@SuppressWarnings("unchecked")
		T view = (T) findViewById(res);
		return view;
	}

	public TabHost getTabHost() {
		return (TabHost) findViewById(android.R.id.tabhost);
	}

	public void addTab(Class<?> activity, String tabSpect, String indicator) {
		TabHost tabHost = (TabHost) findViewById(android.R.id.tabhost);
		TabSpec firstTabSpec = tabHost.newTabSpec(tabSpect);
		firstTabSpec.setIndicator(indicator).setContent(
				new Intent(this, activity));
		tabHost.addTab(firstTabSpec);
	}

	public void addTab(Class<?> activity, String tabSpect, View indicator) {
		TabHost tabHost = (TabHost) findViewById(android.R.id.tabhost);
		TabSpec firstTabSpec = tabHost.newTabSpec(tabSpect);
		firstTabSpec.setIndicator(indicator).setContent(
				new Intent(this, activity));
		tabHost.addTab(firstTabSpec);
	}

	protected Context getContext() {
		return this;
	}

	protected Activity getActivity() {
		return this;
	}

	@Override
	public void onTabChanged(String tabId) {

	}

}