package com.vnp.core.base;

import java.util.HashSet;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

public class BaseItem {
	private Set<String> keys = new HashSet<String>();
	public JSONObject jsonObject;

	public void addKey(String key) {
		keys.add(key);
	}

	public BaseItem(JSONObject jsonObject) {
		this.jsonObject = jsonObject;

		if (this.jsonObject == null) {
			jsonObject = new JSONObject();
		}
	}

	public String getString(String key) {
		try {
			return jsonObject.getString(key);
		} catch (JSONException e) {
			return null;
		}
	}

	public Object getObject(String key) {
		try {
			return jsonObject.get(key);
		} catch (JSONException e) {
			return null;
		}
	}
}