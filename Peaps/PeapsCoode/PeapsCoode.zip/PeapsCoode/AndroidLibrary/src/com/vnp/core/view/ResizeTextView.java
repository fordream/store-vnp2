/**
 * 
 */
package com.vnp.core.view;

import com.vnp.core.common.VNPResize;
import com.vnp.core.common.VNPResize.ICompleteInit;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

/**
 * @author tvuong1pc
 * 
 */
public class ResizeTextView extends TextView {
	private float per = 0.50f;
	private VNPResize vnpResize = VNPResize.getInstance();

	/**
	 * 
	 * @param context
	 * @param baseWidth
	 * @param baseHeight
	 * @param completeInit
	 * @param textView
	 */
	public void initVNPResize(Context context, int baseWidth, int baseHeight,
			ICompleteInit completeInit, TextView textView) {
		vnpResize.init(getContext(), baseWidth, baseHeight, completeInit,
				textView);
	}

	/**
	 * 
	 * @param v
	 * @param width
	 * @param height
	 * @param textSize
	 */
	public void resize(View v, int width, int height, int textSize) {
		vnpResize.resizeSacle(v, width, height);
		vnpResize.setTextsize(v, textSize);
	}

	/**
	 * @param context
	 */
	public ResizeTextView(Context context) {
		super(context);
		init();
	}

	/**
	 * @param context
	 * @param attrs
	 */
	public ResizeTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	/**
	 * @param context
	 * @param attrs
	 * @param defStyle
	 */
	public ResizeTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	private void init() {
		setWillNotDraw(false);
		// setTextSize(2);

	}

	private float size = 0;

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (per > 0 & getHeight() > 0) {
			float heightOneZise = ((float) getLineHeight()) / getTextSize();
			float heightNewLine = (float) getHeight() * per;
			size = heightNewLine / heightOneZise;
		}

		if (size != 0) {
			setTextSize((int) size);
		}
		invalidate();
	}

	private void executeChangSize() {
		post(new Runnable() {
			@Override
			public void run() {
				if (per > 0 & getHeight() > 0) {
					float heightOneZise = ((float) getLineHeight())
							/ getTextSize();
					float heightNewLine = (float) getHeight() * per;
					setTextSize(heightNewLine / heightOneZise);
				}
			}
		});
	}

	/**
	 * 
	 * @param per
	 *            from 0
	 */
	public void setPer(float _per) {
		this.per = _per;
		executeChangSize();
	}
}