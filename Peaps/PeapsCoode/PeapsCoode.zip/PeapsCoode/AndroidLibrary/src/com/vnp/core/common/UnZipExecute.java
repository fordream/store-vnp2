package com.vnp.core.common;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class UnZipExecute {
	public static final String TAG = UnZipExecute.class.getName();
	private static final int BUFFER = 8 * 1024;

	public boolean execute(String pathFileZip, String pathFolderUnZip,
			boolean isDeleteFileZip) {

		// create folder unzip
		LogUtils.e(TAG, "path zip file : " + pathFileZip);
		LogUtils.e(TAG, "path unzip folder : " + pathFolderUnZip);

		File mDirectory = new File(pathFolderUnZip);

		if (!mDirectory.exists()) {
			mDirectory.mkdirs();
		}

		// recheck path
		if (!mDirectory.exists()) {
			LogUtils.e(TAG,
					"start unzip file fail check file path or permistion : "
							+ pathFileZip);
			return false;
		}

		LogUtils.e(TAG, "start unzip file : " + pathFileZip);
		LogUtils.e(TAG, "path unzip folder : don't created");

		File file = new File(pathFileZip);
		try {
			ZipFile zip = new ZipFile(file);
			Enumeration<? extends ZipEntry> zipFileEntries = zip.entries();
			while (zipFileEntries.hasMoreElements()) {
				ZipEntry entry = (ZipEntry) zipFileEntries.nextElement();
				String currentEntry = entry.getName();
				File destFile = new File(pathFolderUnZip, currentEntry);
				File destinationParent = destFile.getParentFile();

				destinationParent.mkdirs();

				if (!entry.isDirectory()) {
					BufferedInputStream is = new BufferedInputStream(
							zip.getInputStream(entry));

					LogUtils.e(TAG, "file name of zip : " + currentEntry);

					int currentByte;
					FileOutputStream fos = new FileOutputStream(destFile);

					byte data[] = new byte[BUFFER];
					BufferedOutputStream dest = new BufferedOutputStream(fos,
							BUFFER);

					while ((currentByte = is.read(data, 0, BUFFER)) != -1) {
						dest.write(data, 0, currentByte);
					}

					dest.flush();
					dest.close();
					is.close();
				}
			}

			LogUtils.e(TAG, "unzip sucess  : " + pathFileZip);
			if (isDeleteFileZip) {
				file.delete();
			}
		} catch (Exception e) {
			LogUtils.e(TAG, "unzip fail  : " + pathFileZip);
			return false;
		}
		return true;
	}
}
