package com.vnp.core.common;

import java.lang.reflect.InvocationTargetException;

import android.content.Context;

public class VnpLoaderClassUtils {
	/**
	 * 
	 * @param pakageClassName
	 *            example: org.com.MClass
	 * @return
	 */
	public static Object getObject(String pakageClassName) {
		Object object = null;

		try {
			Class<?> c = Class.forName(pakageClassName);
			object = c.getConstructor().newInstance();
		} catch (ClassNotFoundException e) {
		} catch (IllegalArgumentException e) {
		} catch (SecurityException e) {
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		} catch (InvocationTargetException e) {
		} catch (NoSuchMethodException e) {
		}

		return object;
	}

	/**
	 * 
	 * @param pakageClassName
	 *            example: org.com.MClass
	 * @return
	 */
	public static Object getObject(String pakageClassName, Context context) {
		Object object = null;

		try {
			Class<?> c = Class.forName(pakageClassName);
			object = c.getConstructor().newInstance(context);
		} catch (ClassNotFoundException e) {
		} catch (IllegalArgumentException e) {
		} catch (SecurityException e) {
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		} catch (InvocationTargetException e) {
		} catch (NoSuchMethodException e) {
		}

		return object;
	}
}