package com.vnp.core.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.vnp.core.common.CommonAndroid;
import com.vnp.core.common.VNPResize;
import com.vnp.core.common.VNPResize.ICompleteInit;

/**
 * add Header Width a text,a button left, a button right, a progess,
 * 
 */
public class HeaderView extends RelativeLayout {
	private Button btnLeft, btnRight;
	private ResizeTextView resizeTextView;
	private ProgressBar progressBar;
	private VNPResize vnpResize = VNPResize.getInstance();

	/**
	 * 
	 * @param context
	 * @param baseWidth
	 * @param baseHeight
	 * @param completeInit
	 * @param textView
	 */
	public void initVNPResize(Context context, int baseWidth, int baseHeight,
			ICompleteInit completeInit, TextView textView) {
		vnpResize.init(getContext(), baseWidth, baseHeight, completeInit, textView);
	}

	/**
	 * 
	 * @param v
	 * @param width
	 * @param height
	 * @param textSize
	 */
	public void resize(View v, int width, int height, int textSize) {
		vnpResize.resizeSacle(v, width, height);
		vnpResize.setTextsize(v, textSize);
	}

	private void init() {
		setGravity(Gravity.CENTER);
		btnLeft = new Button(getContext());
		btnRight = new Button(getContext());
		resizeTextView = new ResizeTextView(getContext());
		resizeTextView.setGravity(Gravity.CENTER);
		progressBar = new ProgressBar(getContext());

		addView(resizeTextView);
		addView(btnLeft);
		addView(btnRight);
		addView(progressBar);
		// hidden all
		// resizeTextView.setVisibility(View.GONE);
		// btnLeft.setVisibility(View.GONE);
		// btnRight.setVisibility(View.GONE);
		// progressBar.setVisibility(View.GONE);
		setHeader("Header");

		setOnClickListener(null);
	}

	/**
	 * 
	 * @param text
	 */
	public void setHeader(String text) {
		resizeTextView.setText(text);
	}

	/**
	 * 
	 * @param text
	 */
	public void setHeader(int text) {
		resizeTextView.setText(text);
	}

	public HeaderView(Context context) {
		super(context);
		init();
		executeChangleSize();
	}

	public HeaderView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
		executeChangleSize();
	}

	public HeaderView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
		executeChangleSize();
	}

	private void executeChangleSize() {
		post(new Runnable() {
			public void run() {
				CommonAndroid.RESIZE._20130408_resizeW960(HeaderView.this, 960,
						150);
				CommonAndroid.RESIZE._20130408_resizeW960(resizeTextView, 960,
						150);
				resizeTextView.setPer(0.5f);
				CommonAndroid.RESIZE._20130408_resizeW960(btnLeft, 150, 100);
				CommonAndroid.RESIZE._20130408_resizeW960(btnRight, 100, 100);
				CommonAndroid.RESIZE._20130408_resizeW960(progressBar, 50, 50);
				CommonAndroid.RESIZE._20130408_sendViewToPositionW960(btnLeft,
						25, 25);
				CommonAndroid.RESIZE._20130408_sendViewToPositionW960(btnRight,
						960 - 25 - 100, 25);
				CommonAndroid.RESIZE._20130408_sendViewToPositionW960(
						progressBar, 960 - 75 - 100 - 2, 75 - 25);
			}
		});
	}

	final public boolean isRunprocess() {
		return progressBar.getVisibility() == View.VISIBLE;
	}

	/**
	 * 
	 * @param isShow
	 */
	final public void showProcess(boolean isShow) {
		progressBar.setVisibility(isShow ? View.VISIBLE : View.GONE);
	}

	/**
	 * 
	 * @param onClickListener
	 * @param message
	 * @param resBackground
	 */
	public void setButtonLeft(View.OnClickListener onClickListener,
			String message, int resBackground) {
		btnLeft.setText(message);
		btnLeft.setBackgroundResource(resBackground);
		btnLeft.setOnClickListener(onClickListener);
		btnLeft.setVisibility(View.VISIBLE);
	}

	/**
	 * 
	 * @param onClickListener
	 * @param message
	 * @param resBackground
	 */

	public void setButtonLeft(View.OnClickListener onClickListener,
			int message, int resBackground) {
		btnLeft.setText(message);
		btnLeft.setBackgroundResource(resBackground);
		btnLeft.setOnClickListener(onClickListener);
		btnLeft.setVisibility(View.VISIBLE);
	}

	/**
	 * 
	 * @param onClickListener
	 * @param message
	 * @param resBackground
	 */
	public void setButtonRight(View.OnClickListener onClickListener,
			String message, int resBackground) {
		btnRight.setText(message);
		btnRight.setBackgroundResource(resBackground);
		btnRight.setOnClickListener(onClickListener);
		btnRight.setVisibility(View.VISIBLE);
	}

	/**
	 * 
	 * @param onClickListener
	 * @param message
	 * @param resBackground
	 */
	public void setButtonRight(View.OnClickListener onClickListener,
			int message, int resBackground) {
		btnRight.setText(message);
		btnRight.setBackgroundResource(resBackground);
		btnRight.setOnClickListener(onClickListener);
		btnRight.setVisibility(View.VISIBLE);
	}
}