package com.vnp.core.common;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;

public class VNPActionbarUtil {
	private Activity context;

	public VNPActionbarUtil(Activity context) {
		this.context = context;
	}

	public ActionBar getActionBar() {
		return context.getActionBar();
	}

	@SuppressLint("NewApi")
	public void hiddenActionBar() {
		getActionBar().hide();
	}
}
